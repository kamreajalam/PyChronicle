import os
import sys
import unittest
import ast

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from visiter import ASTVisitor


class TestASTParser(unittest.TestCase):

    def parse_code(self, code):
        tree = ast.parse(code)

        visitor = ASTVisitor()
        visitor.visit(tree)

        return visitor.data

    def test_import(self):
        result = self.parse_code("import math")
        self.assertIn("math", result["imports"])

    def test_variable(self):
        result = self.parse_code("x = 10")
        self.assertIn("x", result["variables"])

    def test_function(self):
        result = self.parse_code("def hello(): pass")
        self.assertIn("hello", result["functions"])

    def test_class(self):
        result = self.parse_code("class Student: pass")
        self.assertIn("Student", result["classes"])

    def test_for(self):
        result = self.parse_code("for i in range(5): pass")
        self.assertIn("for", result["loops"])

    def test_while(self):
        result = self.parse_code("while True: break")
        self.assertIn("while", result["loops"])

    def test_if(self):
        result = self.parse_code("if True: pass")
        self.assertIn("if", result["conditions"])

    def test_return_does_not_pollute_functions(self):
        """Regression test for the fixed bug: return statements must not
        be appended into the functions list."""
        result = self.parse_code("def hello():\n    return 1")
        self.assertEqual(result["functions"], ["hello"])
        self.assertEqual(len(result["returns"]), 1)
        self.assertEqual(result["returns"][0]["line"], 2)


if __name__ == "__main__":
    unittest.main()
