import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from database import Database
from parser import parse_source

# Always write to pychronicle.db next to this file, so tracer.py and app.py
# always agree on the same database regardless of the current working
# directory the script is launched from.
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pychronicle.db")

# Default target used when no script is passed on the command line.
DEFAULT_SAMPLE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample.py")


class Tracer:
    """Wraps sys.settrace to record execution events into the shared
    PyChronicle SQLite database, so the Textual UI (app.py) can display them.

    trace_file() connects the AST module (parser.py / visiter.py) to the
    runtime tracer: it first statically parses the target script and stores
    that summary in the ast_summary table, then executes the same script
    under trace so its real runtime events land in the events table.
    """

    def __init__(self, db_path=DB_PATH, verbose=False):
        self.db = Database(db_path)
        self.db.create_table()
        self.db.create_ast_table()
        self.verbose = verbose
        self.trace_log = []

    def _trace(self, frame, event, arg):
        function_name = frame.f_code.co_name
        file_name = frame.f_code.co_filename
        line_number = frame.f_lineno

        # Skip the tracer's own control methods (e.g. stop() gets traced once
        # for the call to settrace(None) before tracing actually turns off)
        if function_name in ("start", "stop", "trace_call", "trace_file", "close", "_trace"):
            return self._trace

        # Keep only JSON-serializable locals; fall back to str() for the rest
        local_vars = {}
        for key, value in frame.f_locals.items():
            if key.startswith("__"):
                continue
            try:
                json.dumps(value)
                local_vars[key] = value
            except TypeError:
                local_vars[key] = str(value)

        record = {
            "event": event,
            "function": function_name,
            "file": file_name,
            "line": line_number,
            "variables": local_vars,
        }
        self.trace_log.append(record)

        self.db.insert_event(
            event,
            function_name,
            file_name,
            line_number,
            json.dumps(local_vars),
        )

        if self.verbose:
            print("=" * 50)
            print(record)

        return self._trace

    def start(self):
        sys.settrace(self._trace)

    def stop(self):
        sys.settrace(None)

    def trace_call(self, func, *args, **kwargs):
        """Runs func(*args, **kwargs) under trace and returns its result."""
        self.start()
        try:
            return func(*args, **kwargs)
        finally:
            self.stop()

    def trace_file(self, file_path):
        """Parses (AST) and executes (runtime trace) an arbitrary Python
        script, storing both the static structure and the dynamic
        execution events in the shared database.

        Returns the AST summary dict for the parsed file.
        """
        file_path = os.path.abspath(file_path)
        with open(file_path, "r") as f:
            source_code = f.read()

        # --- AST phase: static analysis ---
        _, summary = parse_source(source_code, file_name=file_path)
        self.db.insert_ast_summary(file_path, summary)

        # --- Runtime phase: dynamic trace ---
        code_obj = compile(source_code, file_path, "exec")
        namespace = {"__name__": "__traced__", "__file__": file_path}

        self.start()
        try:
            exec(code_obj, namespace)
        finally:
            self.stop()

        return summary

    def close(self):
        self.db.close()


if __name__ == "__main__":
    # Any script can be traced: `python tracer.py path/to/script.py`.
    # With no argument, the bundled sample.py is traced as a demonstration.
    target = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_SAMPLE

    tracer = Tracer(verbose=True)
    ast_summary = tracer.trace_file(target)

    print("\nAST summary")
    print("=" * 50)
    print(json.dumps(ast_summary, indent=2))

    print("\nCollected Trace Events")
    print("=" * 50)
    for item in tracer.trace_log:
        print(item)

    print(f"\n{len(tracer.trace_log)} runtime events + AST summary written to {DB_PATH}")
    tracer.close()
