import sqlite3
import json
import os
import shutil
from datetime import datetime


class Database:

    def __init__(self, db_name="pychronicle.db"):
        self.db_name = db_name
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()

    def create_table(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event TEXT,
            function TEXT,
            file TEXT,
            line INTEGER,
            variables TEXT,
            timestamp TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """)
        self.conn.commit()

    def insert_event(self, event, function, file, line, variables):
        self.cursor.execute("""
        INSERT INTO events(event, function, file, line, variables, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (event, function, file, line, variables, datetime.now().isoformat()))

        self.conn.commit()

    def get_all_events(self):
        self.cursor.execute("SELECT * FROM events")
        return self.cursor.fetchall()

    def get_events_by_function(self, function_name):
        self.cursor.execute(
            "SELECT * FROM events WHERE function = ?", (function_name,)
        )
        return self.cursor.fetchall()

    def get_events_by_type(self, event_type):
        self.cursor.execute(
            "SELECT * FROM events WHERE event = ?", (event_type,)
        )
        return self.cursor.fetchall()

    def get_events_by_file(self, file_name):
        self.cursor.execute(
            "SELECT * FROM events WHERE file = ?", (file_name,)
        )
        return self.cursor.fetchall()

    def get_events_in_range(self, start_id, end_id):
        self.cursor.execute(
            "SELECT * FROM events WHERE id BETWEEN ? AND ?", (start_id, end_id)
        )
        return self.cursor.fetchall()

    def get_event_count(self):
        self.cursor.execute("SELECT COUNT(*) FROM events")
        return self.cursor.fetchone()[0]

    def get_unique_functions(self):
        self.cursor.execute("SELECT DISTINCT function FROM events")
        return [row[0] for row in self.cursor.fetchall()]

    def get_execution_summary(self):
        summary = {}

        # Total events
        summary["total_events"] = self.get_event_count()

        # Count per event type
        self.cursor.execute(
            "SELECT event, COUNT(*) FROM events GROUP BY event"
        )
        summary["by_type"] = dict(self.cursor.fetchall())

        # Count per function
        self.cursor.execute(
            "SELECT function, COUNT(*) FROM events GROUP BY function"
        )
        summary["by_function"] = dict(self.cursor.fetchall())

        # Time range
        self.cursor.execute(
            "SELECT MIN(timestamp), MAX(timestamp) FROM events"
        )
        row = self.cursor.fetchone()
        summary["time_start"] = row[0]
        summary["time_end"] = row[1]

        return summary

    def export_to_json(self, file_path="events_export.json"):
        events = self.get_all_events()
        data = []
        for e in events:
            data.append({
                "id": e[0],
                "event": e[1],
                "function": e[2],
                "file": e[3],
                "line": e[4],
                "variables": e[5],
                "timestamp": e[6]
            })

        with open(file_path, "w") as f:
            json.dump(data, f, indent=2)

        return file_path

    def import_from_json(self, file_path):
        with open(file_path, "r") as f:
            data = json.load(f)

        for item in data:
            self.cursor.execute("""
            INSERT INTO events(event, function, file, line, variables, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
            """, (
                item["event"],
                item["function"],
                item["file"],
                item["line"],
                item["variables"],
                item.get("timestamp", datetime.now().isoformat())
            ))

        self.conn.commit()
        return len(data)

    def clear_events(self):
        self.cursor.execute("DELETE FROM events")
        self.conn.commit()

    def search_events(self, keyword):
        self.cursor.execute(
            "SELECT * FROM events WHERE variables LIKE ? OR function LIKE ?",
            (f"%{keyword}%", f"%{keyword}%")
        )
        return self.cursor.fetchall()

    def get_events_by_line(self, line_number):
        self.cursor.execute(
            "SELECT * FROM events WHERE line = ?", (line_number,)
        )
        return self.cursor.fetchall()

    def get_call_stack(self, function_name):
        self.cursor.execute(
            "SELECT * FROM events WHERE function = ? AND event IN ('call', 'return')",
            (function_name,)
        )
        return self.cursor.fetchall()

    def delete_event(self, event_id):
        self.cursor.execute("DELETE FROM events WHERE id = ?", (event_id,))
        self.conn.commit()

    def get_latest_events(self, limit=10):
        self.cursor.execute(
            "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)
        )
        return self.cursor.fetchall()

    def database_info(self):
        info = {}

        # File size
        if os.path.exists(self.db_name):
            size_bytes = os.path.getsize(self.db_name)
            info["file_size"] = f"{size_bytes} bytes"
        else:
            info["file_size"] = "unknown"

        # Row count
        info["row_count"] = self.get_event_count()

        # Column names
        self.cursor.execute("PRAGMA table_info(events)")
        columns = self.cursor.fetchall()
        info["columns"] = [col[1] for col in columns]

        return info

    def get_function_duration(self, function_name):
        self.cursor.execute(
            "SELECT timestamp FROM events WHERE function = ? AND event = 'call'",
            (function_name,)
        )
        call_row = self.cursor.fetchone()

        self.cursor.execute(
            "SELECT timestamp FROM events WHERE function = ? AND event = 'return'",
            (function_name,)
        )
        return_row = self.cursor.fetchone()

        if call_row and return_row:
            start = datetime.fromisoformat(call_row[0])
            end = datetime.fromisoformat(return_row[0])
            duration = (end - start).total_seconds()
            return {"function": function_name, "duration_seconds": duration}

        return {"function": function_name, "duration_seconds": None}

    def get_events_between_timestamps(self, start_time, end_time):
        self.cursor.execute(
            "SELECT * FROM events WHERE timestamp BETWEEN ? AND ?",
            (start_time, end_time)
        )
        return self.cursor.fetchall()

    def backup_database(self, backup_path="pychronicle_backup.db"):
        self.conn.commit()
        shutil.copy2(self.db_name, backup_path)
        return backup_path

    def get_variable_history(self, variable_name):
        self.cursor.execute("SELECT * FROM events WHERE variables LIKE ?",
                            (f"%'{variable_name}'%",))
        results = self.cursor.fetchall()

        history = []
        for r in results:
            variables = r[5]
            history.append({
                "id": r[0],
                "event": r[1],
                "function": r[2],
                "line": r[4],
                "variables": variables,
                "timestamp": r[6]
            })
        return history

    def get_event_by_id(self, event_id):
        self.cursor.execute("SELECT * FROM events WHERE id = ?", (event_id,))
        return self.cursor.fetchone()

    def get_functions_called_by(self, function_name):
        # Get the call and return timestamps of the parent function
        self.cursor.execute(
            "SELECT id FROM events WHERE function = ? AND event = 'call'",
            (function_name,)
        )
        call_row = self.cursor.fetchone()

        self.cursor.execute(
            "SELECT id FROM events WHERE function = ? AND event = 'return'",
            (function_name,)
        )
        return_row = self.cursor.fetchone()

        if call_row and return_row:
            # Find all 'call' events between parent call and return (excluding itself)
            self.cursor.execute(
                "SELECT DISTINCT function FROM events WHERE id > ? AND id < ? AND event = 'call' AND function != ?",
                (call_row[0], return_row[0], function_name)
            )
            return [row[0] for row in self.cursor.fetchall()]

        return []

    def close(self):
        self.conn.close()

    # -- AST static-analysis storage ---------------------------------
    # These methods store the output of the AST module (src/tracer/parser.py
    # + visiter.py) so the UI can show static structure (functions, classes,
    # imports, etc.) alongside the runtime trace events above. One row per
    # source file, keyed by its absolute path; re-parsing a file updates its
    # existing row instead of duplicating it.

    def create_ast_table(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS ast_summary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file TEXT UNIQUE,
            imports TEXT,
            variables TEXT,
            functions TEXT,
            classes TEXT,
            loops TEXT,
            conditions TEXT,
            returns TEXT,
            function_defs TEXT,
            class_defs TEXT,
            parsed_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """)
        self.conn.commit()

    def insert_ast_summary(self, file_path, summary):
        """Stores (or updates, if this file was already parsed) the AST
        visitor's summary dict for a given source file."""
        self.cursor.execute("""
        INSERT INTO ast_summary(
            file, imports, variables, functions, classes,
            loops, conditions, returns, function_defs, class_defs, parsed_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(file) DO UPDATE SET
            imports=excluded.imports,
            variables=excluded.variables,
            functions=excluded.functions,
            classes=excluded.classes,
            loops=excluded.loops,
            conditions=excluded.conditions,
            returns=excluded.returns,
            function_defs=excluded.function_defs,
            class_defs=excluded.class_defs,
            parsed_at=excluded.parsed_at
        """, (
            file_path,
            json.dumps(summary.get("imports", [])),
            json.dumps(summary.get("variables", [])),
            json.dumps(summary.get("functions", [])),
            json.dumps(summary.get("classes", [])),
            json.dumps(summary.get("loops", [])),
            json.dumps(summary.get("conditions", [])),
            json.dumps(summary.get("returns", [])),
            json.dumps(summary.get("function_defs", [])),
            json.dumps(summary.get("class_defs", [])),
            datetime.now().isoformat(),
        ))
        self.conn.commit()

    def get_ast_summary(self, file_path):
        """Returns the stored AST summary dict for a file, or None."""
        self.cursor.execute("SELECT * FROM ast_summary WHERE file = ?", (file_path,))
        row = self.cursor.fetchone()
        if not row:
            return None
        return {
            "id": row[0],
            "file": row[1],
            "imports": json.loads(row[2] or "[]"),
            "variables": json.loads(row[3] or "[]"),
            "functions": json.loads(row[4] or "[]"),
            "classes": json.loads(row[5] or "[]"),
            "loops": json.loads(row[6] or "[]"),
            "conditions": json.loads(row[7] or "[]"),
            "returns": json.loads(row[8] or "[]"),
            "function_defs": json.loads(row[9] or "[]"),
            "class_defs": json.loads(row[10] or "[]"),
            "parsed_at": row[11],
        }

    def get_all_ast_files(self):
        """Returns the list of file paths that have a stored AST summary."""
        self.cursor.execute("SELECT file FROM ast_summary")
        return [row[0] for row in self.cursor.fetchall()]