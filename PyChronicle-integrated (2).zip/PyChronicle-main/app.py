import sys
import os
import json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src", "tracer"))

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Header, Footer, Static, ListView, ListItem
from rich.syntax import Syntax
from database import Database


class PyChronicleApp(App):
    """PyChronicle UI - displays real traced events (runtime + AST) from the
    SQLite database. Populated by running src/tracer/tracer.py first."""

    BINDINGS = [("d", "toggle_dark", "Toggle Dark Mode"), ("q", "quit", "Quit")]

    CSS = """
    #sidebar-box {
        width: 40;
        background: $panel;
        border-right: vkey $accent;
        padding: 1;
    }
    #sidebar-title {
        text-align: center;
        background: $accent;
        color: $text;
        margin-bottom: 1;
        text-style: bold;
    }
    #main-workspace {
        background: $surface;
    }
    #code-viewer-panel {
        height: 3fr;
        padding: 1 2;
        border-bottom: solid $accent;
    }
    .panel-title {
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }
    #code-display {
        background: $boost;
        padding: 1;
    }
    #bottom-inspector-box {
        height: 1fr;
        background: $background;
        padding: 1 2;
    }
    #var-display {
        background: $boost;
        padding: 1;
    }
    #stats-display {
        text-align: center;
        background: $accent;
        color: $text;
        margin-top: 1;
        padding: 0 1;
    }
    """

    def __init__(self):
        super().__init__()
        db_path = os.path.join(os.path.dirname(__file__), "src", "tracer", "pychronicle.db")
        self.db = Database(db_path)
        self.db.create_table()
        self.db.create_ast_table()
        self.events = self.db.get_all_events()

    def compose(self) -> ComposeResult:
        yield Header()

        with Horizontal():
            with Vertical(id="sidebar-box"):
                yield Static(" TRACE TIMELINE ", id="sidebar-title")

                # Build list items from real database events
                items = []
                for event in self.events:
                    event_id = event[0]
                    event_type = event[1]
                    func_name = event[2]
                    line_num = event[4]
                    label = f"[{event_type}] {func_name}() line {line_num}"
                    items.append(
                        ListItem(Static(label), id=f"event_{event_id}")
                    )

                yield ListView(*items, id="log-list")

                # Show stats at bottom of sidebar: runtime events/functions
                # plus how many source files have AST data stored, so the
                # AST -> SQLite -> UI link is visible, not just runtime data.
                count = len(self.events)
                functions = self.db.get_unique_functions()
                ast_files = self.db.get_all_ast_files()
                yield Static(
                    f" {count} events | {len(functions)} functions | "
                    f"{len(ast_files)} file(s) AST-parsed ",
                    id="stats-display"
                )

            with Vertical(id="main-workspace"):
                with Vertical(id="code-viewer-panel"):
                    yield Static(" SOURCE CODE VIEWER ", id="code-title", classes="panel-title")
                    yield Static(
                        "Select a trace event to view details...",
                        id="code-display"
                    )

                with Vertical(id="bottom-inspector-box"):
                    yield Static(" VARIABLE INSPECTOR ", id="inspector-title", classes="panel-title")
                    yield Static("No variables tracked.", id="var-display")

        yield Footer()

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Shows real source code and variables when a trace event is selected."""
        if event.item and event.item.id:
            # Extract event ID from the item id (format: "event_19")
            event_id = int(event.item.id.replace("event_", ""))
            db_event = self.db.get_event_by_id(event_id)

            if db_event:
                event_type = db_event[1]
                func_name = db_event[2]
                file_name = db_event[3]
                line_num = db_event[4]
                timestamp = db_event[6]

                self.query_one("#code-title", Static).update(
                    f" {event_type.upper()} · {func_name}() · line {line_num} · {timestamp} "
                )

                # Show the real source file, highlighting the exact traced
                # line, instead of a synthesized placeholder function body.
                colored_code = self._render_source(file_name, line_num)
                self.query_one("#code-display", Static).update(colored_code)

                # Show variables (stored as JSON by the tracer)
                variables = db_event[5]
                if variables and variables != "{}":
                    try:
                        parsed = json.loads(variables)
                        pretty = "\n".join(f"  {k} = {v!r}" for k, v in parsed.items())
                        var_display = f"Variables at this point:\n\n{pretty}"
                    except (json.JSONDecodeError, TypeError):
                        var_display = f"Variables at this point:\n\n{variables}"
                else:
                    var_display = "No variables at this point."

                self.query_one("#var-display", Static).update(var_display)

    def _render_source(self, file_name, line_num):
        """Reads the real traced source file from disk and returns a
        Syntax-highlighted snippet centered on the traced line. Falls back
        to a plain message if the file can't be read (e.g. moved/deleted
        since it was traced)."""
        try:
            with open(file_name, "r") as f:
                source = f.read()
        except OSError:
            return Syntax(
                f"# Source file not available:\n# {file_name}",
                "python",
                theme="monokai",
            )

        total_lines = source.count("\n") + 1
        start = max(1, line_num - 4)
        end = min(total_lines, line_num + 4)

        return Syntax(
            source,
            "python",
            theme="monokai",
            line_numbers=True,
            line_range=(start, end),
            highlight_lines={line_num},
        )

    def action_toggle_dark(self) -> None:
        self.theme = (
            "textual-light" if self.theme == "textual-dark" else "textual-dark"
        )

    def on_unmount(self) -> None:
        """Close database when app exits."""
        self.db.close()


if __name__ == "__main__":
    app = PyChronicleApp()
    app.run()
